<template>
    <div id="mine">
        我的页面
    </div>
</template>
<script>
    export default {
    name: 'mine',
    data(){
        return{
        }
    },
    methods: {}
}
</script>
<style lang="less" scoped>
    #mine{
       
    }
</style>
